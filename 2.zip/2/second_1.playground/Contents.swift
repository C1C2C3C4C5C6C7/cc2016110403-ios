import UIKit

//var str = "Hello, playground"
let inDict = [["name":"cc", "age":20],["name":"asd", "age":88],["name":"fgh", "age":50]]
let inAge = inDict.map( {$0["age"]!} )
let strArr = ["123", "cc", "abcd", "123456"]
let strToInt = strArr.filter( {Int($0) != nil} )
let initialStr = ["cc", "homework", "hard"]
var mergedStr = initialStr.reduce("", {$0+","+$1})
mergedStr.remove(at: mergedStr.startIndex)
let intArr = [12,2,1,-3,98,100]
let requiredNum = intArr.reduce((max:intArr[0], min:intArr[0],sum:0), {(max:max($0.max,$1),min:min($0.min,$1), sum:$0.sum+$1)})
print("用map函数返回age字符串数组为：",inAge)
print("能被转成Int的字符串:",strToInt)
print("用reduce函数把String数组中元素连接成一个字符串，以逗号分隔:",mergedStr)
print("整数数组的最大值、最小值、总数和分别为:",requiredNum)


//函数类型为(Int, Int)->Int
func f1(x:Int, y:Int)->Int{
    return x-y
}

//函数类型为(Int)->Int
func f2(x:Int)->Int{
    return x
}

//函数类型为(Int)->void
func f3(x:Int){
}

//函数类型为(String)->Int
func f4(x:String)->Int{
    return Int(x)!
}

//函数类型为()->Int
func f5()->Int{
    return 0
}

let funcArr:[Any] = [f1, f2, f3, f4, f5]
for(index, value) in funcArr.enumerated(){
    if value is (Int)->Int{
        print("函数类型为(Int)->Int的函数是第",index+1,"个")
    }
}


extension Int{
    func sqrt()->Double{
        return Foundation.sqrt(Double(self))
    }
}
print("扩展Int，增加sqrt方法，4的平方根是：",4.sqrt())


func getMaxAndMin<T:Comparable>(arr:T...)->(T,T){
    var max = arr[0]
    var min = arr[1]
    for item in arr{
        if item>max{
            max = item
        }
        if item < min {
            min = item
        }
    }
    return (max, min)
}
print("(5,5,8,6,9,88,10,01)中最大值和最小值分别为:",getMaxAndMin(arr:5,5,8,6,9,88,10,01))
print("(5.3,6.5,36,22)中最大值和最小值分别为:",getMaxAndMin(arr:5.3,6.5,36,22))
print("(abce,aghj,sakura,zxy)中最大值和最小值分别为:",getMaxAndMin(arr:"asd","dfg","hjgj","jiu"))
