import UIKit

var str = "Hello, playground"
    enum Gender: Int {
           case male
           case female
           case unknow
           static func >(lhs: Gender, rhs: Gender) -> Bool {
                   return lhs.rawValue < rhs.rawValue
               }
      }


   enum Department {
            case one, two, three
        }



   class Person: CustomStringConvertible  {
            var firstName: String  //姓
            var lastName: String  //名
            var age: Int  //年龄
            var gender: Gender  //性别
    
           var fullName: String {  //全名
                    get {
                            return firstName + lastName
                       }
                }
    
            //构造方法
            init(firstName: String, lastName: String, age: Int, gender: Gender) {
                    self.firstName = firstName
                   self.lastName = lastName
                    self.age = age
                    self.gender = gender
                }
    
            convenience init(firstName: String, age: Int, gender: Gender) {
                    self.init(firstName: firstName, lastName: "", age: age, gender: gender)
                }
    
            convenience init(firstName: String) {
                   self.init(firstName: firstName, age: 0, gender: Gender.unknow)
                }
    
           required convenience init() {
                    self.init(firstName: "")
                }
    
           //重载==
    static func ==(lhs: Person, rhs: Person) -> Bool {
                    return lhs.fullName == rhs.fullName && lhs.age == rhs.age && lhs.gender == rhs.gender
               }

           //重载!=
          static func !=(lhs: Person, rhs: Person) -> Bool {
                   return !(lhs == rhs)
            }

           //实现CustomStringConvertible协议中的计算属性，可以使用print直接输出对象内容
           var description: String {
                return "fullName: \(self.fullName), age: \(self.age), gender: \(self.gender)"
               }
    
    
       }

  var p1 = Person(firstName: "we")
   var p2 = Person(firstName: "re", age: 50, gender: .male)
   print(p1)
   print(p1 == p2)
   print(p1 != p2)

