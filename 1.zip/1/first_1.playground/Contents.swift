import UIKit

//var str = "Hello, playground"
var priInit = [Int]()
for i in 2...100{
    var isPrime=true
    for j in 2..<i {
        if i%j == 0{
            isPrime = false
        }
    }
    if isPrime {
        priInit.append(i)
    }
}
priInit.append(3)
priInit.append(5)
priInit.append(2)
print("未排序：", priInit)

var priOrder1 = priInit
priOrder1.sort()
//正序
print("正序：", priOrder1)
func reverse(x : Int, y : Int)->Bool{
    return x > y
}
var priReverse1 = priInit.sorted(by: reverse)
//逆序
print("逆序：", priReverse1)

//名称缩写
var priReverse2 = priInit.sorted(by: {$0 > $1})
var priOrder2 = priInit.sorted(by: {$0 < $1})
print("正序：", priOrder2)
print("逆序：", priReverse2)

//使用自定的排序方法
func positiveOrder(x : Int, y : Int)->Bool{
    return x < y
}
var priOrder3 = priInit.sorted(by: positiveOrder)
print("正序：", priOrder3)

//根据上下文推断类型的排序
var priReverse4 = priInit.sorted(by: {x, y in  return x>y})
var priOrder4 = priInit.sorted(by: {x, y in return x<y})
print("正序：", priOrder4)
print("逆序：", priReverse4)

//闭包表达式
var priReverse5 = priInit.sorted(by: {(x:Int, y:Int)->Bool in return x>y})
var priOrder5 = priInit.sorted(by: {(x:Int, y:Int)->Bool in  return x<y})
print("正序：", priOrder5)
print("逆序：", priReverse5)

//单表达式闭包隐式返回
var priReverse6 = priInit.sorted(by: {x, y in x>y})
var priOrder6 = priInit.sorted(by: {x,y in x<y})
print("正序：", priOrder6)
print("逆序：", priReverse6)


