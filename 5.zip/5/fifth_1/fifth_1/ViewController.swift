//
//  ViewController.swift
//  fifth_1
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 chenchen. All rights reserved.
//

import UIKit
class MyViewController:UIViewController{
    var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.gray
        
        //创建UILabel对象
        label = UILabel(frame: CGRect(x: 200, y: 200, width: 150, height: 40))
        label.text = "is too hard"
        label.backgroundColor = UIColor.yellow
        self.view.addSubview(label)
        
        //创建UIButton对象
        let btn = UIButton(frame: CGRect(x: 100, y: 250, width: 100, height: 40))
        btn.setTitle("别按我", for: .normal)
        btn.layer.borderWidth = 1                   //设置按钮边框宽度
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.addTarget(self, action: #selector(clicked), for: .touchUpInside)    //给按钮添加target-action
        self.view.addSubview(btn)
        
        //创建UIImageView对象
        let imageView = UIImageView(frame: CGRect(x: 10, y: 400, width: self.view.frame.width - 20, height: (self.view.frame.width - 20) * 0.618))
        let path = Bundle.main.path(forResource: "111", ofType: "jpg")        //获取图片资源路径
        let image = UIImage(contentsOfFile: path!)
        imageView.image = image
        self.view.addSubview(imageView)
    }
    
    
    /// 按钮点击事件，改变label显示的文字
    @objc func clicked() {
        if label.text == "is too hard" {
            label.text = "i have said that 别按我"
        } else {
            label.text = "is too hard"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}


