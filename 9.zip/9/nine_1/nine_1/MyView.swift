//
//  MyView.swift
//  nine_1
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 chenchen. All rights reserved.
//

import Foundation
import UIKit


@IBDesignable
class MyView:UIView{
    @IBInspectable var strokeColor: UIColor = UIColor.red
    override func draw(_ rect: CGRect) {
        let path = UIBezierPath()
        path.move(to: CGPoint(x:rect.width,y:0))
        path.addLine(to: CGPoint(x:rect.width/2,y:rect.height))
        path.addLine(to: CGPoint(x:0,y:0))
        path.close()
        
        let r = CGFloat(Float(Int(arc4random()) % 256))
        let g = CGFloat(Float(Int(arc4random()) % 256))
        let b = CGFloat(Float(Int(arc4random()) % 256))
        let myColor = UIColor.init(red: r/255, green: g/255, blue: b/255, alpha: 1)
        
        
        myColor.setStroke()
        path.stroke()
        
        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(gesture:))))
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(tap(gesture:)))
        tapRecognizer.numberOfTapsRequired = 2
        tapRecognizer.numberOfTouchesRequired = 1
        addGestureRecognizer(tapRecognizer)
        
        addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinch(gesture:))))
        
        addGestureRecognizer(UIRotationGestureRecognizer(target:self,action:#selector(rotation(gesture:))))
        
    }
    func setup(){
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    @objc func pan(gesture: UIPanGestureRecognizer) {
        switch gesture.state {
        case .changed, .ended:
            let translation = gesture.translation(in: self)
            let x = center.x + translation.x
            let y = center.y + translation.y
            center = CGPoint(x: x, y: y)
            gesture.setTranslation(CGPoint.zero, in: self)
            
        default:
            break
        }
        self.reloadInputViews()
    }
    
    @objc func tap(gesture: UITapGestureRecognizer) {
        switch gesture.state {
        case .ended:
            self.removeFromSuperview()
        default:
            break
        }
        self.reloadInputViews()
    }
    @objc func pinch(gesture: UIPinchGestureRecognizer)  {
        switch gesture.state {
        case .changed,.ended:
            //            self.contentScaleFactor = gesture.scale + 1
            
            let scare = gesture.scale
            self.transform = CGAffineTransform(scaleX: scare, y: scare)
        default:
            break
        }
        self.reloadInputViews()
    }
    
    @objc func rotation(gesture: UIRotationGestureRecognizer) {
        
        switch gesture.state {
        case .changed,.ended:
            let r = gesture.rotation
            self.transform = CGAffineTransform(rotationAngle: r)
        default:
            break
        }
        self.reloadInputViews()
    }
}
