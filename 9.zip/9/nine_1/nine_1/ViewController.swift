//
//  ViewController.swift
//  nine_1
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 chenchen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var clearBtn: UIButton!
    
    @IBOutlet weak var addBtn: UIButton!
    
    @IBOutlet weak var moveBtn: UIButton!
    private func createNewView(){
        let width=100
        let height=50
        let x = Int(arc4random()) % (Int(self.view.bounds.width ) - width)
        let y = Int(arc4random()) % (Int(self.view.bounds.height ) - height)
        let myView = MyView(frame: CGRect(x: x, y: y, width: width, height: height))
        myView.backgroundColor = UIColor.clear
        self.view.insertSubview(myView, at: 0)
    }
    private func clearMyView(){
        for subview  in self.view.subviews{
            if subview is MyView{
                subview.removeFromSuperview()
            }
        }
    }
    var i:Int = 0
    private func moveMyView(){
        for subview  in self.view.subviews{
            if subview is MyView{
                let x = Int(arc4random()) % Int(self.view.bounds.width)
                let y = Int(arc4random()) % Int(self.view.bounds.height)
                UIView.animate(withDuration: 2, delay: 0, options: [.repeat, .autoreverse], animations: {
                    subview.center = CGPoint(x: x, y: y)
                }, completion: nil)
                
            }
            
        }
    }
    @IBAction func clickButton(_ sender: UIButton) {
        let title:String = sender.currentTitle!
        switch title {
        case "addView":
            createNewView()
        case "clearView":
            clearMyView()
        case "moveView":
            moveMyView()
        default:
            break
        }
        //print(title)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //createNewView()
        addBtn.layer.shadowOpacity = 0.5
        addBtn.layer.cornerRadius = 10
        addBtn.layer.shadowColor = UIColor.black.cgColor
        addBtn.layer.shadowOffset = CGSize(width: 10, height: 10)
        moveBtn.layer.shadowOpacity = 0.5
        moveBtn.layer.cornerRadius = 10
        moveBtn.layer.shadowColor = UIColor.black.cgColor
        moveBtn.layer.shadowOffset = CGSize(width: 10, height: 10)
        clearBtn.layer.shadowOpacity = 0.5
        clearBtn.layer.cornerRadius = 10
        clearBtn.layer.shadowColor = UIColor.black.cgColor
        clearBtn.layer.shadowOffset = CGSize(width: 10, height: 10)
        clearBtn.layer.shadowOpacity = 0.5
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
