//
//  ViewController.swift
//  forth_1
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 chenchen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let manager = FileManager.default
        let document = manager.urls(for: .documentDirectory, in: .userDomainMask).first?.path
        let file = document?.appending("/img") //图片文件夹
        if manager.fileExists(atPath: file!) {
            let image = file?.appending("/111.jpg")  //图片文件
            if manager.fileExists(atPath: image!) {  //若该文件存在，则显示到界面上
                do{
                    let data = try Data(contentsOf: URL(fileURLWithPath: image!))
                    let img = UIImage(data: data)
                    let imageView = UIImageView(image: img)
                    imageView.frame = CGRect(x: 0, y: 100, width: 400, height: 300)
                    self.view.addSubview(imageView)
                } catch {
                    print(error)
                }
            } else {
                let url = URL(string: "http://image.baidu.com/search/detail?ct=503316480&z=0&ipn=d&word=猴子&step_word=&hs=2&pn=2&spn=0&di=26965223690&pi=0&rn=1&tn=baiduimagedetail&is=0%2C0&istype=0&ie=utf-8&oe=utf-8&in=&cl=2&lm=-1&st=undefined&cs=340970538%2C513121451&os=965986979%2C4116431119&simid=0%2C0&adpicid=0&lpn=0&ln=1927&fr=&fmq=1545042664356_R&fm=&ic=undefined&s=undefined&hd=undefined&latest=undefined&copyright=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&ist=&jit=&cg=&bdtype=13&oriquery=&objurl=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Fc995d143ad4bd1132db007c650afa40f4afb05c0.jpg&fromurl=ipprf_z2C%24qAzdH3FAzdH3Ffp5vh_z%26e3Bp7vi5g2_z%26e3Bv54AzdH3Ft4w2j%3Ft4w2jI1%3D8nanna9ll8cblaa09b%26f576vj%3Dkwt17t4w2j&gsm=0&rpstart=0&rpnum=0&islist=&querylist=&selected_tags=0")
                
                class ViewController: UIViewController {
                    
                    override func viewDidLoad() {
                        super.viewDidLoad()
                        // Do any additional setup after loading the view, typically from a nib.
                        
                        let manager = FileManager.default
                        let document = manager.urls(for: .documentDirectory, in: .userDomainMask).first?.path
                        let file = document?.appending("/img") //图片文件夹
                        
                        if manager.fileExists(atPath: file!) {
                            let image = file?.appending("/222.jpg")  //图片文件
                            if manager.fileExists(atPath: image!) {  //若该文件存在，则显示到界面上
                                do{
                                    let data = try Data(contentsOf: URL(fileURLWithPath: image!))
                                    let img = UIImage(data: data)
                                    let imageView = UIImageView(image: img)
                                    imageView.frame = CGRect(x: 0, y: 100, width: 400, height: 300)
                                    self.view.addSubview(imageView)
                                } catch {
                                    print(error)
                                }
                            } else {  //若不存在，则从网络下载一个图片并保存
                                let url = URL(string: "http://image.baidu.com/search/detail?ct=503316480&z=0&ipn=d&word=猴子&step_word=&hs=2&pn=2&spn=0&di=26965223690&pi=0&rn=1&tn=baiduimagedetail&is=0%2C0&istype=0&ie=utf-8&oe=utf-8&in=&cl=2&lm=-1&st=undefined&cs=340970538%2C513121451&os=965986979%2C4116431119&simid=0%2C0&adpicid=0&lpn=0&ln=1927&fr=&fmq=1545042664356_R&fm=&ic=undefined&s=undefined&hd=undefined&latest=undefined&copyright=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&ist=&jit=&cg=&bdtype=13&oriquery=&objurl=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Fc995d143ad4bd1132db007c650afa40f4afb05c0.jpg&fromurl=ipprf_z2C%24qAzdH3FAzdH3Ffp5vh_z%26e3Bp7vi5g2_z%26e3Bv54AzdH3Ft4w2j%3Ft4w2jI1%3D8nanna9ll8cblaa09b%26f576vj%3Dkwt17t4w2j&gsm=0&rpstart=0&rpnum=0&islist=&querylist=&selected_tags=0")
                                do{
                                    let data = try Data(contentsOf: url!)
                                    try data.write(to: URL(fileURLWithPath: image!), options: .atomicWrite)
                                    print("文件不存在，已成功创建文件")
                                } catch {
                                    print(error)
                                }
                            }
                        } else {  //若该文件夹不存在，则创建该文件夹
                            do {
                                try manager.createDirectory(atPath: file!, withIntermediateDirectories: true, attributes: nil)
                                print("文件夹不存在，已成功创建文件夹")
                            } catch {
                                print(error)
                            }
                        }
                    }
                    
                    
                }
                

                do{
                    let data = try Data(contentsOf: url!)
                    try data.write(to: URL(fileURLWithPath: image!), options: .atomicWrite)
                    print("文件不存在，已成功创建文件")
                } catch {
                    print(error)
                }
            }
        } else {
            do {
                try manager.createDirectory(atPath: file!, withIntermediateDirectories: true, attributes: nil)
                print("文件夹不存在，已成功创建文件夹")
            } catch {
                print(error)
            }
        }
    }
    
    
}



